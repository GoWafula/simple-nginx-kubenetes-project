# 🚀 Deploying NGINX on Kubernetes with Ingress (K3s + Killercoda)

This project demonstrates a full Kubernetes workflow using a lightweight K3s cluster on Killercoda. We deploy an NGINX web server, expose it via a Service, and route external traffic using Traefik Ingress.

## 🧰 Tools Used

- Kubernetes (K3s)
- kubectl
- Traefik (Ingress controller)
- Killercoda (for lab environment)
- YAML

## 📦 Kubernetes Resources

- `Deployment`: Manages pod lifecycle
- `Service`: Exposes pod internally
- `Ingress`: Routes traffic using Traefik

## 🛠️ Setup Steps

```bash
kubectl apply -f nginx-deployment.yaml
kubectl apply -f nginx-service.yaml
kubectl apply -f nginx-ingress.yaml
```

> Add `127.0.0.1 nginx.local` to `/etc/hosts` for local hostname routing.

## 🔁 Scale and Heal

```bash
kubectl scale deployment nginx-deployment --replicas=3
kubectl delete pod <pod-name>  # Observe self-healing
```

## 🔍 Logs and Debugging

```bash
kubectl logs <pod>
kubectl describe pod <pod>
```

## 🌐 Ingress Output

![Ingress Preview](./screenshots/ingress-setup.png)

## 📘 Lessons Learned

- Kubernetes is declarative and self-healing.
- YAML manifests define your entire app setup.
- Ingress enables clean routing using hostnames like `nginx.local`.

## ✨ Bonus Ideas

- Add ConfigMaps and Secrets
- Setup rolling updates
- Secure with HTTPS using cert-manager

## 📚 Blog Version

Read the full write-up on Medium: [link-to-article]
